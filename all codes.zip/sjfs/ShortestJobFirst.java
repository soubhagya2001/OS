package sjfs;

import java.util.Arrays;
import java.util.Scanner;

public class ShortestJobFirst {
    static class Process {
        int pid;
        int bt;
        int at;
        
        public Process(int pid, int bt, int at) {
            this.pid = pid;
            this.bt = bt;
            this.at = at;
        }
    }
    
    public static void findAvgTime(Process[] proc, int n) {
        int[] wt = new int[n];
        int[] tat = new int[n];
        
        // Initialize remaining time to burst time and completed flag to false for each process
        int[] rem_bt = new int[n];
        boolean[] completed = new boolean[n];
        for (int i = 0; i < n; i++) {
            rem_bt[i] = proc[i].bt;
            completed[i] = false;
        }
        
        // Initialize the current time and the total completed time
        int t = 0;
        int total_tat = 0;
        int total_wt = 0;
        
        while (true) {
            // Find the process with the minimum remaining time that has arrived
            int min_bt = Integer.MAX_VALUE;
            int min_idx = -1;
            for (int i = 0; i < n; i++) {
                if (proc[i].at <= t && !completed[i] && rem_bt[i] < min_bt) {
                    min_bt = rem_bt[i];
                    min_idx = i;
                }
            }
            
            // If no process has arrived yet, increase the current time
            if (min_idx == -1) {
                t++;
                continue;
            }
            
            // Update the remaining time for the selected process
            rem_bt[min_idx]--;
            
            // If the remaining time for the selected process is 0, mark it as completed
            if (rem_bt[min_idx] == 0) {
                completed[min_idx] = true;
                
                // Calculate turnaround time and waiting time for the completed process
                tat[min_idx] = t + 1 - proc[min_idx].at;
                wt[min_idx] = tat[min_idx] - proc[min_idx].bt;
                
                // Update the total completed time, total waiting time, and total turnaround time
                total_tat += tat[min_idx];
                total_wt += wt[min_idx];
            }
            
            // Increase the current time
            t++;
            
            // If all processes have been completed, exit the loop
            if (Arrays.stream(completed).allMatch(x -> x)) {
                break;
            }
        }
        
        // Display process information along with average waiting time and average turnaround time
        System.out.println("Process ID\tBurst Time\tArrival Time\tWaiting Time\tTurnaround Time");
        for (int i = 0; i < n; i++) {
            System.out.println(proc[i].pid + "\t\t" + proc[i].bt + "\t\t" + proc[i].at + "\t\t"
                    + wt[i] + "\t\t" + tat[i]);
        }
     
        // Calculate average waiting time and average turnaround time
        float avg_wt = (float) total_wt / (float) n;
        float avg_tat = (float) total_tat / (float) n;
     
        // Display average waiting time and average turnaround time
        System.out.println("Average Waiting Time: " + avg_wt);
        System.out.println("Average Turnaround Time: " + avg_tat);
    }
    
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter the number of processes: ");
        int n = scanner.nextInt();
        
        System.out.println("Enter the burst time and arrival time :");
        // Create an array of Process objects and input the process information
        Process[] proc = new Process[n];
        for (int i = 0; i < n; i++) {
            System.out.print(" for process " + (i+1) + ": ");
            int bt = scanner.nextInt();
            int at = scanner.nextInt();
            proc[i] = new Process(i+1, bt, at);
        }
        
        // Call the findAvgTime method to calculate the average waiting time and average turnaround time
        findAvgTime(proc, n);
    }
}
