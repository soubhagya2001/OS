package priority;

import java.util.*;

class Process2 {
    int id;
    int arrivalTime;
    int burstTime;
    int priority;
    int tempPriority;
    int startTime;
    int completionTime;
    int waitingTime;
    int turnaroundTime;

    public Process2(int id, int arrivalTime, int burstTime, int priority) {
        this.id = id;
        this.arrivalTime = arrivalTime;
        this.burstTime = burstTime;
        this.priority = priority;
        this.tempPriority = priority;
        this.startTime = 0;
        this.completionTime = 0;
        this.waitingTime = 0;
        this.turnaroundTime = 0;
    }
}

public class PriorityAging {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter the number of processes: ");
        int n = scanner.nextInt();

        List<Process2> processes = new ArrayList<>();

        System.out.println("Enter Arrival , Burst , Priority ");
        for (int i = 0; i < n; i++) {
            System.out.println("for process " + (i + 1) + ":");
            int arrivalTime = scanner.nextInt();
            int burstTime = scanner.nextInt();
            int priority = scanner.nextInt();

            Process2 process = new Process2(i + 1, arrivalTime, burstTime, priority);
            processes.add(process);
        }

        // Sort processes based on arrival time
        processes.sort(Comparator.comparingInt((Process2 p) -> p.arrivalTime));

        int currentTime = 0;
        int completedProcesses = 0;

        while (completedProcesses < n) {
            Process2 selectedProcess = null;
            int highestPriority = Integer.MAX_VALUE;

            for (Process2 process : processes) {
                if (process.arrivalTime <= currentTime && !processes.contains(process) && process.priority < highestPriority) {
                    highestPriority = process.priority;
                    selectedProcess = process;
                }
            }

            if (selectedProcess == null) {
                currentTime++;
                continue;
            }

            selectedProcess.startTime = currentTime;
            selectedProcess.completionTime = selectedProcess.startTime + selectedProcess.burstTime;
            currentTime = selectedProcess.completionTime;
            selectedProcess.waitingTime = selectedProcess.startTime - selectedProcess.arrivalTime;
            selectedProcess.turnaroundTime = selectedProcess.completionTime - selectedProcess.arrivalTime;

            completedProcesses++;

            // Aging: Increase the priority of waiting processes
            for (Process2 process : processes) {
                if (process.arrivalTime <= currentTime && process != selectedProcess) {
                    process.priority--;
                }
            }
        }

        System.out.println("\nProcess\tArrival\tBurst\tPriority\tStart\tCompletion\tWaiting\tTurnaround");
        System.out.println("--------------------------------------------------------------------------------------------------------------------------");
        for (Process2 process : processes) {
            System.out.println(process.id + "\t\t" + process.arrivalTime + "\t\t" + process.burstTime + "\t\t" +process.tempPriority+"\t\t"+
                    process.startTime + "\t\t" + process.completionTime + "\t\t\t" + process.waitingTime +
                    "\t\t\t" + process.turnaroundTime);
        }

        scanner.close();
    }
}

